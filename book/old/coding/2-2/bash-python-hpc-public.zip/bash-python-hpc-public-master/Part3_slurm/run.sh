
# job params
params="--mem=1G --time=00:30:00 --ntasks=1 --cpus-per-task=1"

# account specification for DelftBlue
params=$params" --account=Education-CEG-Courses-CEGM1000"

# number of samples for seed
nsamples=10

# add jobs for seeds in specified range
for seed in `seq 1 $nsamples`
do
  echo "running $seed"

  # it's better to have an individual job name for each task
  jobparams=$params" --job-name='poisson.$seed'"


  # put job into the queue. '&' - for non-blocking execution
  srun $jobparams python poisson.py $seed &
done

echo "Jobs are put into queue"

# wait until all the jobs finish
wait

echo "Calculation finished"

echo "Plotting started"
jobparams=$params" --job-name='poisson.plot'"
srun $jobparams python plot_results.py ./results/sol*.npy
echo "Plotting finished"
