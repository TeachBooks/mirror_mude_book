import numpy as np
import sys
import os
import time
import platform
import matplotlib.pyplot as plt 

# The get_Matrix function which returns matrix K and receives as variables:
# - The number of degrees of points "n"
# - The distance between points "dx" (x in the equations)
# - The constant "nu"
def get_matrix(n, dx, nu):
    # Create an n x n matrix with zeros on every entry
    K = np.zeros((n,n))
    
    # For each point in from 1 to n-1 add the influence of the point and of it's surroundings
    for i in range(1, n-1):
        K[i, i] += 2*nu/dx**2
        K[i, i-1] -= nu/dx**2
        K[i, i+1] -= nu/dx**2
    return K


# The apply_BCs function adapts matrix K and vector f to ensure boundary conditions will be satisfied. Inputs:
# - K matrix
# - f vector
# - the temperature on the left side "T_left"
# - the temperature on the right side "T_right"
def apply_BCs(K, f, T_left, T_right):
    #Apply boundary condition at left side:
    K[0, 0] = 1
    f[0] = T_left
    
    #Apply boundary condition at right side:
    K[-1, -1] = 1
    f[-1] = T_right
    
    
def solve_poisson(T_left=38, nu=4):
    # Defining the given values of our problem:
    #T_left = 38        # Temperature at the left
    T_right = 25       # Temperature at the right
    T_initial = 7      # Initial temperature of the bar
    length = 300       # Length of the bar in mm
    n_point = 1000       # Number of points
    #nu = 4             # Constant value nu mm^2/s (representative value for steel)
    nt = 200           # Number of time increments

    # Calculating the distance between each point if we equally space them 
    dx = length / (n_point - 1)
    x = np.linspace(0, length, n_point)

    # Creating vector with source values
    q = -.002
    f = q * np.ones(n_point)
    
    # Get the matrix that relates u to source f using the getMatrix function
    K = get_matrix(n_point, dx, nu)   
    apply_BCs(K, f, T_left, T_right)

    # Solve equation Ku = f directly using linear solver
    u = np.linalg.solve(K, f)

    return x,u

# generate T_left values with normal distribution using seed
def generate(seed):
    np.random.seed(seed)
    T_left =  np.random.normal(loc=38, scale=10, size=1)
    nu =  np.random.normal(loc=4, scale=1, size=1)
    return T_left, nu

# run Monte-Carlo simulation for number of samples
def run_MC(n_samples=10):
    # generate values and put the values into arrays
    t_left_values = np.zeros(n_samples)
    nu_values = np.zeros(n_samples)
    for i in range(n_samples):
        t_left_values[i], nu_values[i] = generate(i)    


    for i in range(n_samples):
        x, u = solve_poisson(T_left=t_left_values[i], nu=nu_values[i])
        plt.plot(x, u)
    plt.xlabel('x')
    plt.ylabel('Temperature')
    plt.savefig('result.png')


# solve Poisson equation for a given seed
def run():
    # get seed value from command line parameter
    if len(sys.argv) < 2:
        print('Not enough parameters!')
        exit(1)
    seed = int(sys.argv[1])
    
    T_left, nu = generate(seed)

    start = time.perf_counter()
    x,u = solve_poisson(T_left=T_left[0], nu=nu[0])
    end = time.perf_counter()

    print('Hostname:', platform.node(), 'Seed:', seed, 'Time:', '{:.5f}'.format(end - start), 'sec.')

    # create directory for results (sol_*.npy)
    if not os.path.exists('results'):
        os.mkdir('results')

    # save solution vector u(x)
    # add T_left and nu values to filenames (keep only 5 digits)
    suffix = '{:.5f}_{:.5f}'.format(T_left[0], nu[0])
    with open('results/sol_' + suffix + '.npy', 'wb') as f:
        np.save(f, u)

    # save x vector
    if not os.path.exists('results/x.npy'): # save it only once -
                                       # to avoid simultaneous writing to the same file during 
                                       # the concurrent runs with different T_left
        with open('results/x.npy', 'wb') as f:
            np.save(f, x)


#run_MC()
run()
