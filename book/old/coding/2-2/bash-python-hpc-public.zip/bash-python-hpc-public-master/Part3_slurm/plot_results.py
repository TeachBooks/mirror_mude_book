import numpy as np
import sys
from matplotlib import pyplot as plt

# this script reads x  from result dir
# reads specified sol files from cmd parameters 
# plots and outputs to result.png

# how to run this script: python plot_results.py ./results/sol*.npy

if __name__ == '__main__':

    # read x points
    with open('results/x.npy', 'rb') as f:
        x = np.load(f)

    # read solution vectors and plot them (they should be specified in cmd line params)
    # argv[0] is the filename of the current script
    for fname in sys.argv[1:]:
        print('Adding',fname, 'to plot')
        with open(fname, 'rb') as f:
            u = np.load(f)
        plt.plot(x, u)

    plt.xlabel('x')
    plt.ylabel('Temperature')
    plt.savefig('result.png')
